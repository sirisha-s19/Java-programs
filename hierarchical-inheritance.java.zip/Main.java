class Animal {
    void eat() {
        System.out.println("Animal eating");
    }
}

class Dog extends Animal {
    void bark() {
        System.out.println("Dog barking");
    }
}

class Cat extends Animal {
    void meow() {
        System.out.println("Cat meowing");
    }
}

public class Main {
    public static void main(String[] args) {

        Dog d = new Dog();
        d.bark();
        d.eat();

        Cat c = new Cat();
        c.meow();
        c.eat();
    }
}